const startGrpcServer = require('./server/grpcServer');

startGrpcServer();
